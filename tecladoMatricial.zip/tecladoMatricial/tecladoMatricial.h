#ifndef TECLADOMATRICIAL_H
#define TECLADOMATRICIAL_H

#include <Arduino.h>

class tecladoMatricial{
     public:
           String insertName();
           String insertNumber();
           tecladoMatricial(int _col1,int _col2,int _col3,int _lin1,int _lin2,int _lin3,int _lin4); 
 
     private:
          char nome1[20] = {};
          char num1[10] = {};
          long tempo;
          long timer;
          long tempoEspera = 0;
          long tempoEsperaEntre = 0;
          int col1,col2,col3,lin1,lin2,lin3,lin4;
          char tecl0[2] = {' ','0'},
               tecl1[1] = {'1'},
               tecl2[4] = {'A','B','C','2'},
               tecl3[4] = {'D','E','F','3'},
               tecl4[4] = {'G','H','I','4'},
               tecl5[4] = {'J','K','L','5'},
               tecl6[4] = {'M','N','O','6'},
               tecl7[5] = {'P','Q','R','S','7'},
               tecl8[4] = {'T','U','V','8'},
               tecl9[5] = {'W','X','Y','Z','9'};
          #define tempoMaximoDeUmaPalma  150 //milisegundos
          #define tempoMaximoEntrePalmas 500 //milisegundos
          int  tecla0,tecla1,tecla2,tecla3,tecla4,tecla5,tecla6,tecla7,tecla8,tecla9,cursr,pos,linha;
          bool tec0,tec1,tec2,tec3,tec4,tec5,tec6,tec7,tec8,tec9,tecAx;
          bool lin1_,lin2_,lin3_,lin4_,lin1c2,lin2c2,lin3c2,lin4c2,lin1c3,lin2c3,lin3c3,lin4c3;
               
  };



#endif

#include <tecladoMatricial.h>


tecladoMatricial :: tecladoMatricial(int _col1,int _col2,int _col3,int _lin1,int _lin2,int _lin3,int _lin4){
    col1 = _col1;
    col2 = _col2;
    col3 = _col3;
    lin1 = _lin1;
    lin2 = _lin2;
    lin3 = _lin3;
    lin4 = _lin4;
    pinMode(col1,OUTPUT);
    pinMode(col2,OUTPUT);
    pinMode(col3,OUTPUT);


    pinMode(lin1,INPUT_PULLUP); 
    pinMode(lin2,INPUT_PULLUP);
    pinMode(lin3,INPUT_PULLUP); 
    pinMode(lin4,INPUT_PULLUP); 

    for(int x = col1; x < col3 + 1;x++){
           digitalWrite(x, HIGH);
           }
  };

//******************************************************************************************************************************************************


  String tecladoMatricial:: insertNumber(){
         
           for(int x = col1;x < col3 + 1; x ++){
    
          digitalWrite(x,LOW);
                  if(!digitalRead(col1)){
                         if(!digitalRead(lin1)) lin1_ = true;
                         if(digitalRead(lin1) && lin1_){
                            lin1_ = false;
                            num1[cursr] = {'1'};
                            cursr++;
                            
                           }//fim linha 1
                   if(!digitalRead(lin2)) lin2_ = true;
                         if(digitalRead(lin2) && lin2_){
                            lin2_ = false;
                            num1[cursr] = {'4'};
                            cursr++;
                            
                           }//fim linha 2
    
                   if(!digitalRead(lin3)) lin3_ = true;
                         if(digitalRead(lin3) && lin3_){
                            lin3_ = false;
                            num1[cursr] = {'7'};
                            cursr++;
                            
                           }//fim linha 3 
                    if(!digitalRead(lin4)) lin4_ = true;
                         if(digitalRead(lin4) && lin4_){
                            lin4_ = false;
                            num1[cursr] = {'*'};
                            cursr++;
                            
                           }//fim linha 4   
    
                           
                    
                 }//fim coluna 1
            else if(!digitalRead(col2)){
                         if(!digitalRead(lin1)) lin1c2 = true;
                         if(digitalRead(lin1) && lin1c2){
                            lin1c2 = false;
                            num1[cursr] = {'2'};
                            cursr++;
                            
                           }//fim linha 1
                   if(!digitalRead(lin2)) lin2c2 = true;
                         if(digitalRead(lin2) && lin2c2){
                            lin2c2 = false;
                            num1[cursr] = {'5'};
                            cursr++;
                            
                           }//fim linha 2
    
                   if(!digitalRead(lin3)) lin3c2 = true;
                         if(digitalRead(lin3) && lin3c2){
                            lin3c2 = false;
                            num1[cursr] = {'8'};
                            cursr++;
                            
                           }//fim linha 3 
                    if(!digitalRead(lin4)) lin4c2 = true;
                         if(digitalRead(lin4) && lin4c2){
                            lin4c2 = false;
                            num1[cursr] = {'0'};
                            cursr++;
                            
                           }//fim linha 4   
    
                           
                    
                 }//fim coluna 2 
    
             else if(!digitalRead(col3)){
                         if(!digitalRead(lin1)) lin1c3 = true;
                         if(digitalRead(lin1) && lin1c3){
                            lin1c3 = false;
                            num1[cursr] = {'3'};
                            cursr++;
                            
                           }//fim linha 1
                   if(!digitalRead(lin2)) lin2c3 = true;
                         if(digitalRead(lin2) && lin2c3){
                            lin2c3 = false;
                            num1[cursr] = {'6'};
                            cursr++;
                            
                           }//fim linha 2
    
                   if(!digitalRead(lin3)) lin3c3 = true;
                         if(digitalRead(lin3) && lin3c3){
                            lin3c3 = false;
                            num1[cursr] = {'9'};
                            cursr++;
                            
                           }//fim linha 3 
                    if(!digitalRead(lin4)) lin4c3 = true;
                         if(digitalRead(lin4) && lin4c3){
                            lin4c3 = false;
                            num1[cursr] = {'#'};
                            cursr++;
                            
                           }//fim linha 4   
    
                           
                    
                 }//fim coluna 3       
                    
                digitalWrite(x,HIGH);  
                  
                  
                  
                  }

             return num1;     
          
  
  };

//******************************************************************************************************************************************************

  String tecladoMatricial :: insertName(){
   
      for(int x = col1;x < col3 + 1; x ++){
                 digitalWrite(x,LOW);
              if(!digitalRead(col1)){
                  if(!digitalRead(lin1)) lin1_ = true;
                         if(digitalRead(lin1) && lin1_){
                            lin1_ = false;
                            nome1[cursr] = {'1'};
                            cursr++;
                            
                           }
                  
                  
                 else if(!digitalRead(lin2)){  //TECLA 4
                     
                     if (tempoEspera == 0){
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla4 < 4){
                          }
                          tecla4 ++;
                          if(tecla4 > 4) tecla4 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla4 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl4[tecla4-1]};
                           cursr++;
                           
                           tecla4 = 0;
                           tempoEsperaEntre = millis();
                        }  
                 
                
                           
                else if(!digitalRead(lin3)){   // tecla7 
                    if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla7 < 5){
                          }
                          tecla7 ++;
                          if(tecla7 > 5) tecla7 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla7 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl7[tecla7-1]};
                           cursr++;
                           
                           tecla7 = 0;
                           tempoEsperaEntre = millis();
                        }  
                  
                  
                  
                                 
                else if(!digitalRead(lin4)){
                    tecAx = true;
                  }
                  if(digitalRead(lin4) && tecAx ){
                     tecAx = false;
                     nome1[cursr-1] = {' '};
                     cursr--;
                     if((linha >0) && cursr == 0){
                      linha--;
                      cursr = 19;
                     }
                    
                  }
                  if(cursr < 0) cursr = 0;
                }
                  
        
           if(!digitalRead(col2)){
                  if(!digitalRead(lin1)){   // tecla 2
                    if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla2 < 4){
                          }
                          tecla2 ++;
                          if(tecla2 > 4) tecla2 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla2 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl2[tecla2-1]};
                           cursr++;
                           
                           tecla2 = 0;
                           tempoEsperaEntre = millis();
                        }  
                    
                    
                    
                                   
                 else if(!digitalRead(lin2)){     //tecla5
                     if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis();
                          if(tecla5 < 4){
                          }
                          tecla5 ++;
                          if(tecla5 > 4) tecla5 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla5 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl5[tecla5-1]};
                           cursr++;
                           
                           tecla5 = 0;
                           tempoEsperaEntre = millis();
                        }  
                   
                  
                              
                else if(!digitalRead(lin3)){        //tecla 8
                  if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla8 < 4){
                          }
                          tecla8 ++;
                          if(tecla8 > 4) tecla8 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla8 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl8[tecla8-1]};
                           cursr++;
                           
                           tecla8 = 0;
                           tempoEsperaEntre = millis();
                        }  
                  
                                    
                else if(!digitalRead(lin4)){        //tecla 0
                   if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla0 < 2){
                          }
                          tecla0 ++;
                          if(tecla0 > 4) tecla0 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla0 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl0[tecla0-1]};
                           cursr++;
                           
                           tecla0 = 0;
                           tempoEsperaEntre = millis();
                        }
                                 
                  
           }
          if(!digitalRead(col3)){
                  if(!digitalRead(lin1)){                  //tecla 3 
                    if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla3 < 4){
                          }
                          tecla3 ++;
                          if(tecla3 > 4) tecla3 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla3 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl3[tecla3-1]};
                           cursr++;
                           
                           tecla3 = 0;
                           tempoEsperaEntre = millis();
                        }
                    
                                      
                 else if(!digitalRead(lin2)){        //tecla 6
                  if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla6 < 4){
                          }
                          tecla6 ++;
                          if(tecla6 > 4) tecla6 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla6 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl6[tecla6-1]};
                           cursr++;
                           
                           tecla6 = 0;
                           tempoEsperaEntre = millis();
                        }
                  
                                
                else if(!digitalRead(lin3)){                 //tecla 9
                    if (tempoEspera == 0) {
                          tempoEspera = tempoEsperaEntre = millis(); 
                          if(tecla9 < 5){
                          }
                          tecla9 ++;
                          if(tecla9 > 5) tecla9 = 0;
                          
                          
                          
                       } else if ((millis() - tempoEspera) >= tempoMaximoDeUmaPalma) {
                          tempoEspera = 0;
                       }
                    }
                    if ( (tecla9 != 0) && ((millis() - tempoEsperaEntre) > 500) ) {
                           nome1[cursr] = {tecl9[tecla9-1]};
                           cursr++;
                           
                           tecla9 = 0;
                           tempoEsperaEntre = millis();
                        }
                  
                  
                                
                 else if(!digitalRead(lin4)) lin4_ = true;
                         if(digitalRead(lin4) && lin4_){
                            lin4_ = false;
                            nome1[cursr] = {'#'};
                            cursr++;
                            
                           } 
                     
                 
                 
                  
          }    
                
                
           digitalWrite(x,HIGH);  
              
              
              
              }

              return nome1;
  
  };
